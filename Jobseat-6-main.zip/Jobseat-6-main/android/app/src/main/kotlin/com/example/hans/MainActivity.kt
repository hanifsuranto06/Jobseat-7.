package com.example.hans

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
